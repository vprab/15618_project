#!/bin/bash -f
xv_path="/home/ricson/data/Vivado/2016.4"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim testbench_behav -key {Behavioral:sim_1:Functional:testbench} -tclbatch testbench.tcl -view /home/ricson/data/Vivado/2016.4/bin/project_5/project_5_behav.wcfg -log simulate.log
